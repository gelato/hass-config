import{cZ as r}from"./card-fe58fbb1.js";function o(o){const s=r(o);return s.setHours(23,59,59,999),s}export{o as e};
